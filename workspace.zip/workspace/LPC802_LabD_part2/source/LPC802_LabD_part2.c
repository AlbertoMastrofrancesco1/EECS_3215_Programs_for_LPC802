// EECS 3215 Lab D, part 2
#include "LPC802.h"
int main(void) {

	// Turn on the GPIO system.
	SYSCON->SYSAHBCLKCTRL0 |= SYSCON_SYSAHBCLKCTRL0_GPIO0_MASK;

	// loop infinitely
	while(1)

	{
		asm("NOP");
	}
}// end of main

// for labD part2 demo demonstrate
//that you can turn the LED on and off
//by alternatively setting bit 9 in GPIO’s CLR0
//and SET0 registers.  Also, show
//that the value in GPIO’s B8 Byte Registers updates
//when you press the User button.
