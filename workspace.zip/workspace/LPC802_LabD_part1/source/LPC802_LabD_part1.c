#include "LPC802.h"

#define LED_USER1 (9) //led green
#define LED_USER2 (8) //led blue
#define LED_USER3 (17) // red


int main(void)
{
	SYSCON->SYSAHBCLKCTRL0 |= (SYSCON_SYSAHBCLKCTRL0_GPIO0_MASK);

	// Set data direction on
  // GPIO*ON* to Output.
	GPIO->DIRSET[0] = (1UL<<LED_USER3);
	GPIO->DIRSET[0] = (1UL<<LED_USER1);
	GPIO->DIRSET[0] = (1UL<<LED_USER2);



  // Turn on the LED. (*red grreen blue*)
	GPIO->CLR[0] = (1UL<<LED_USER3);
	GPIO->CLR[0] = (1UL<<LED_USER1);
	GPIO->CLR[0] = (1UL<<LED_USER2);



  // loop infinitely
  while(1)
  {   //                                                                    |                                                                                                                           |
	  delay();   //blink red green blue led on and off @ time defined below V
	 GPIO->NOT[0] = (1UL<<LED_USER3);
	 GPIO->NOT[0] = (1UL<<LED_USER1);
	  GPIO->NOT[0] = (1UL<<LED_USER2);

  }


} // end of main


void delay(void)    // blink_time of delay
{
	int a = 0;
	for( a = 0; a < 200000; a = a + 1 )  // change a < #; for speed
	{
		asm("NOP");
	}
}
