/*ch6_ctimer_ch0_match_isr_50duty.c
* Use the CTimer Match to output pulses to *
* 1. Blue LED (GPIO 8) indirectly via Interrupt on Match on CTIMER Ch. 0.
 // CTimer to drive an ISR to change GPIO directly */

#include "LPC802.h"
#include "clock_config.h"  // for BOARD_BootClockFRO30M(), etc.

#define CTIMER_MATCH_VALUE (1000000) // visible LED blinking: 1000000+ ***SPEED***
#define CTIMER_PRESCALE (1)  // (1 to 2^32): Pre-scale divisor for APB clock for CTIMER counter

#define LED_USER1 (8) // Blue LED (LD19 LD20)
#define LED_USER2 (9) // Red LED (LD21 and LD22; and LD5)


int main(void) {

    // disable interrupts
	__disable_irq();        // turn off globally
	NVIC_DisableIRQ(CTIMER0_IRQn);  // turn off the CTIMER interrupt.

    // ----------------------- Begin Core Clock Select  -----------------------
	// Specify that we will use the Free-Running Oscillator, Set the main clock to be the FRO
	// 0x0 is FRO; 0x1 is external clock ; 0x2 is Low pwr osc.; 0x3 is FRO_DIV
	// Place in bits 1:0 of MAINCLKSEL.
	SYSCON->MAINCLKSEL = (0x0<<SYSCON_MAINCLKSEL_SEL_SHIFT);


    // Update the Main Clock
	// Step 1. write 0 to bit 0 of this register
	// Step 2. write 1 to bit 0 this register
	SYSCON->MAINCLKUEN &= ~(0x1); // step 1
	SYSCON->MAINCLKUEN |= 0x1;  // step 2

    // Set the FRO frequency
	// For FRO at  9MHz: BOARD_BootClockFRO18M(); 12MHz: BOARD_BootClockFRO24M(); 15MHz: BOARD_BootClockFRO30M();
	BOARD_BootClockFRO24M();
	// ----------------------- End of Core Clock Select  -----------------------

    // ----------------------- Begin GPIO setup ------------------------------------
	// Set up a general GPIO for use within the Interrupt Service Routine for CTIMER
	// Only the ISR needs the GPIO.  (GPIO 8)
	SYSCON->SYSAHBCLKCTRL0 |= (SYSCON_SYSAHBCLKCTRL0_GPIO0_MASK);       // GPIO is on
	GPIO->DIRSET[0] = (1UL<<LED_USER1);     // output on GPIO 8
	GPIO->CLR[0] = (1UL<<LED_USER1);     // LED is on GPIO 8
	// ----------------------- end of GPIO setup -----------------------------------


 // ---------------------- Begin CTIMER code (Match on Ch 0) ---------------
	// Match and Interrupt on Ch. 0.  Toggle within the ISR.
	// Enable the CTIMER clock: SYSCON->SYSAHBCLKCTRL0 CTIMER0 clock
	SYSCON->SYSAHBCLKCTRL0 |= (SYSCON_SYSAHBCLKCTRL0_CTIMER0_MASK);

    // Reset the CTIMER module
	// 1. Assert CTIMER-RST-N
	// 2. Clear CTIMER-RST-N
	SYSCON->PRESETCTRL0 &= ~(SYSCON_PRESETCTRL0_CTIMER0_RST_N_MASK);   // Reset
	SYSCON->PRESETCTRL0 |= (SYSCON_PRESETCTRL0_CTIMER0_RST_N_MASK);  // clear the reset.

 // Match Channel 0 and generate IRQ
	CTIMER0->MCR |= CTIMER_IR_MR0INT_MASK;   // interrupt on Ch 0 match

 // Match at this rate for ch 0 for ISR
	CTIMER0->MR[0] = CTIMER_MATCH_VALUE; // this should determine period

 // prescale the counter clock from APB bus.
	CTIMER0->PR = (CTIMER_PRESCALE-1); // PR = 0: Divide by 1 of APB clock; PR = 1: Divide by 2; PR = 2: Divide by 3...

	// Enable the timer.
	CTIMER0->TCR |= CTIMER_TCR_CEN_MASK;

    // At this point, the TCR ENable bit gets set to 1 and then, automatically, we should see the timer TCVAL value change.
	// that should confirm that the timer is actually running.
	// ---------------------- end of CTIMER code --------------------------

 // enable global interrupts & the CTIMER IRQ.
	NVIC_EnableIRQ(CTIMER0_IRQn);  __enable_irq();  // global


    /* Enter an infinite loop, do nothing in particular here.*/
while(1) {
	asm("NOP");
}
	return 0 ;
}

// Interrupt Service Routine for _all_ CTIMER functions
void CTIMER0_IRQHandler(void)  {

	 // Test the bit for Interrupt on Match Channel 0
	if(((CTIMER0->IR)>>CTIMER_IR_MR0INT_SHIFT) & 1)
		{

		// RESET the interrupt flag by writing a ONE (1) to the bit.
		// Only concerned with Channel 0 Matching.
		CTIMER0->IR = CTIMER_IR_MR0INT_MASK;


	  // toggle LED
		GPIO->NOT[0] = (1UL<<LED_USER1);

	  // Manually reset the timer.
	  // Set the timer counter and prescale counter back to 0
		CTIMER0->TCR |= CTIMER_TCR_CRST_MASK; // set bit 1 to 1
		CTIMER0->TCR &= ~(CTIMER_TCR_CRST_MASK);   // clear bit 1 to 0
		}
			else
		{
			// all other interrupt requests for CTIMER would end up here.
				asm("NOP");
		}
			return;
}
