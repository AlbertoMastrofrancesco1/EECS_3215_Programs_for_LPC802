/* Final Project: EECS 3215
 * Alberto Mastrofrancesco 214107742
 *
 * LPC802
 * -------SIMPLE FOUR BUTTON PASSCODE ACCESS KEYPAD---------
 */

/* Include Statements */

//libraries
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "LPC802.h"
#include "fsl_debug_console.h"

/* Definitions */

#define LED_USER1 (8) //led blue for heartbeat (SYSTICK)
//digits on 7-segment x4
#define digit1 (17)                        //  "
#define digit2 (11)                        //PIO0's
#define digit3 (14)                        //  "
#define digit4 (10)                        //  "
//segments per digit x8
#define A (4)
#define B (0)
#define C (13)
#define D (9)
#define E (7)
#define F (12)
#define G (1)
//push buttons x4
#define pushbutton1 (1)
#define pushbutton2 (2)
#define pushbutton3 (6)
#define pushbutton4 (8)
//________________________________________________________________________________

/* Main Argument/ Begin */

int main(void) {

	/* added systeick heartbeat with blue led*/

		__disable_irq();
		NVIC_DisableIRQ(SysTick_IRQn);

	//at startup make display show '   ' (blank)
	    SYSCON->MAINCLKSEL = (0x0<<SYSCON_MAINCLKSEL_SEL_SHIFT);
		SYSCON->MAINCLKUEN &= ~(0x1); // step 1
		SYSCON->MAINCLKUEN |= 0x1;  // step 2
		BOARD_BootClockFRO24M();
		SysTick_Config(2400000);  //for heartbeat
		SYSCON->SYSAHBCLKCTRL0 |= (SYSCON_SYSAHBCLKCTRL0_GPIO0_MASK);       // GPIO is on
		SYSCON->PRESETCTRL0 &= ~(SYSCON_PRESETCTRL0_GPIO0_RST_N_MASK);  // reset GPIO(bit=0) (SYStick)
		SYSCON->PRESETCTRL0 |= (SYSCON_PRESETCTRL0_GPIO0_RST_N_MASK);  // clear reset (bit=1) (SYStick)
		GPIO ->CLR[0] = (1UL<<LED_USER1); //(SYSTICK)
		GPIO ->DIRSET[0] = (1UL<<LED_USER1); //(SYSTICK)
		// Enable IRQs (SysTick & global)
			NVIC_EnableIRQ(SysTick_IRQn);
			// SysTick IRQs are on
			__enable_irq();  // global

		GPIO->DIRSET[0] = (1UL<<digit1)|(1UL<<digit2)|(1UL<<digit3)|(1UL<<digit4)|(1UL<<A)|(1UL<<B)|(1UL<<C)|(1UL<<D)|(1UL<<E)|(1UL<<F)|(1UL<<G);
		GPIO->SET[0] = (1UL<<A)|(1UL<<B)|(1UL<<C)|(1UL<<D)|(1UL<<E)|(1UL<<F)|(1UL<<G);
		GPIO->CLR[0] = (1UL<<digit1)|(1UL<<digit2)|(1UL<<digit3)|(1UL<<digit4);
		while(1) {

/* Set 1: AAAA */

			GPIO->NOT[0]=(1UL<<A)|(1UL<<B)|(1UL<<C)|(1UL<<E)|(1UL<<F)|(1UL<<G);
			GPIO->NOT[0]=(1UL<<digit1);  //digit 1 is on; displays A
			GPIO->NOT[0]=(1UL<<digit2);  //digit 1 is on; displays A
			GPIO->NOT[0]=(1UL<<digit3);  //digit 1 is on; displays A
			GPIO->NOT[0]=(1UL<<digit4);  //digit 1 is on; displays A */

/* Set 2: BBBB */

			/*GPIO->NOT[0]=(1UL<<A)|(1UL<<B)|(1UL<<C)|(1UL<<D)|(1UL<<E)|(1UL<<F)|(1UL<<G);
			GPIO->NOT[0]=(1UL<<digit1);  //digit 1 is on; displays B
			GPIO->NOT[0]=(1UL<<digit2);  //digit 1 is on; displays B
			GPIO->NOT[0]=(1UL<<digit3);  //digit 1 is on; displays B
			GPIO->NOT[0]=(1UL<<digit4);  //digit 1 is on; displays B */

/* Set 3: CCCC */

			/*GPIO->NOT[0]=(1UL<<A)|(1UL<<D)|(1UL<<E)|(1UL<<F);
			GPIO->NOT[0]=(1UL<<digit1);  //digit 1 is on; displays C
			GPIO->NOT[0]=(1UL<<digit2);  //digit 1 is on; displays C
			GPIO->NOT[0]=(1UL<<digit3);  //digit 1 is on; displays C
			GPIO->NOT[0]=(1UL<<digit4);  //digit 1 is on; displays C */

/* Set 4: DDDD */

			GPIO->NOT[0]=(1UL<<A)|(1UL<<B)|(1UL<<C)|(1UL<<D)|(1UL<<E)|(1UL<<F)|(1UL<<G);
			GPIO->NOT[0]=(1UL<<digit1);  //digit 1 is on; displays D
			GPIO->NOT[0]=(1UL<<digit2);  //digit 1 is on; displays D
			GPIO->NOT[0]=(1UL<<digit3);  //digit 1 is on; displays D
			GPIO->NOT[0]=(1UL<<digit4);  //digit 1 is on; displays D */

			}
			return 0;
}

void SysTick_Handler(void) {

	GPIO ->NOT[0] = (1UL<<LED_USER1); //RED

}


