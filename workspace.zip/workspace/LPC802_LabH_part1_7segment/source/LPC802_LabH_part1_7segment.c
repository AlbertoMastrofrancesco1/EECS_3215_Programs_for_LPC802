// 7 segment to display my student # 214107742


#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "LPC802.h"
#include "fsl_debug_console.h"

// Definitions.
// Enable signals.
#define digit1 (17)
#define digit2 (11)                        //using 4 of the digits
#define digit3 (14)
#define digit4 (10)

// Segment
#define A (4)                                 //    ___
#define B (16)                                 //   |___|
#define C (13)                                //   |___|
#define D (9)
#define E (7)
#define F (12)
#define G (1)

int main(void) {
	SYSCON->MAINCLKSEL = (0x0<<SYSCON_MAINCLKSEL_SEL_SHIFT);
	SYSCON->MAINCLKUEN &= ~(0x1); // step 1
	SYSCON->MAINCLKUEN |= 0x1;  // step 2
	BOARD_BootClockFRO24M();
	SYSCON->SYSAHBCLKCTRL0 |= (SYSCON_SYSAHBCLKCTRL0_GPIO0_MASK);       // GPIO is on
	GPIO->DIRSET[0] = (1UL<<digit1)|(1UL<<digit2)|(1UL<<digit3)|(1UL<<digit4)|(1UL<<A)|(1UL<<B)|(1UL<<C)|(1UL<<D)|(1UL<<E)|(1UL<<F)|(1UL<<G);
	GPIO->SET[0] = (1UL<<A)|(1UL<<B)|(1UL<<C)|(1UL<<D)|(1UL<<E)|(1UL<<F)|(1UL<<G);
	GPIO->CLR[0] = (1UL<<digit1)|(1UL<<digit2)|(1UL<<digit3)|(1UL<<digit4);
	while(1) {

		// DIGIT 1 ON
		GPIO->NOT[0]=(1UL<<A)|(1UL<<B)|(1UL<<C);  // a,b,c,d,e,f,g = on
		GPIO->NOT[0]=(1UL<<digit1);  //digit 1 is on
		for(int i = 0; i<1000000; i++) {       //FOR TO MAKE IT BLINK
			asm("NOP");


		//DIGIT 1 OFF
		GPIO->NOT[0]=(1UL<<A)|(1UL<<B)|(1UL<<C);
		GPIO->NOT[0]=(1UL<<digit1);
		//dig 2 on
		GPIO->NOT[0]=(1UL<<A)|(1UL<<B)|(1UL<<C);
		GPIO->NOT[0]=(1UL<<digit2);
		for(int i = 0; i<1000000; i++) {
				asm("NOP");
		}

		//DIGIT 2 OFF
		GPIO->NOT[0]=(1UL<<A)|(1UL<<B)|(1UL<<C);
		GPIO->NOT[0]=(1UL<<digit2);
		//dig3 on
		GPIO->NOT[0]=(1UL<<B)|(1UL<<C)|(1UL<<F)|(1UL<<G);
		GPIO->NOT[0]=(1UL<<digit3);
			for(int i = 0; i<1000000; i++) {
					asm("NOP");
		}

		//DIGIT 3 OFf
		GPIO->NOT[0]=(1UL<<B)|(1UL<<C)|(1UL<<F)|(1UL<<G);
		GPIO->NOT[0]=(1UL<<digit3);
		//dig 4 on
		GPIO->NOT[0]=(1UL<<A)|(1UL<<B)|(1UL<<D)|(1UL<<E)|(1UL<<G);
		GPIO->NOT[0]=(1UL<<digit4);
			for(int i = 0; i<1000000; i++) {
				asm("NOP");
		}

		GPIO->NOT[0]=(1UL<<A)|(1UL<<B)|(1UL<<D)|(1UL<<E)|(1UL<<G);
		GPIO->NOT[0]=(1UL<<digit4);

		}
	}
		return 0 ;
}
