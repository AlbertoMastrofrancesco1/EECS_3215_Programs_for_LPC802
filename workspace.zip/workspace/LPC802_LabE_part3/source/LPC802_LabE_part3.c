// eecs 3215 lab e part 3
// user button is Pio0_8 (GPIO 8)
// led is PIO0_9 (GPIO_9)

#include "LPC802.h"
#define LED   (9)  // One of the LED (PIO0_9)
#define BUTTON_USER1 (8)  // GPIO 8 (PIO0_8) is connected to the LED.

 void PIN_INT0_IRQHandler(void)
 {

	 // was an IRQ requested for Channel 0 of GPIO INT?
	 if (PINT->IST & (1<<0))
	 {
		 // remove the any IRQ flag for Channel 0 of GPIO INT
		 PINT->IST = (1<<0);   // TOggle the LED
		 GPIO->NOT[0] = (1UL<<LED);
	 }
	 else
	 {
		 asm("NOP");  // Place a breakpt here if debuggin
	 }
  return;
 }



int main(void)
{
     // disable interrupts
	__disable_irq();        // turn off globally
	NVIC_DisableIRQ(PIN_INT0_IRQn);  // turn off the PIN INT0 interrupt.

	// ----------------------- Begin GPIO setup ------------------------------------
	// Set up a general GPIO for use
	// Only the ISR needs the GPIO.
	SYSCON->SYSAHBCLKCTRL0 |= ( SYSCON_SYSAHBCLKCTRL0_GPIO0_MASK |  // GPIO is on
	SYSCON_SYSAHBCLKCTRL0_GPIO_INT_MASK); // GPIO Interrupt is on

	// Put 0 in the GPIO and GPIO Interrupt reset bit to reset it.
	// Then put a 1 in the GPIO and GPIO Interrupt reset bit to allow both to operate.

	// reset GPIO and GPIO Interrupt  (bit=0)
	SYSCON->PRESETCTRL0 &= ~(SYSCON_PRESETCTRL0_GPIO0_RST_N_MASK | SYSCON_PRESETCTRL0_GPIOINT_RST_N_MASK);

	// clear reset  (bit=1)
    SYSCON->PRESETCTRL0 |= (SYSCON_PRESETCTRL0_GPIO0_RST_N_MASK | SYSCON_PRESETCTRL0_GPIOINT_RST_N_MASK);

    // Config the Pushbutton (GPIO 8) for input and LED (GPIO 9) for output
    // Remember: only bits set to 1 have an effect on DIRCLR and DIRSET registers.
    //        bits cleared to 0 are ignored.
    //    Therefore, use DIRCLR to select input and DIRSET to select output
    GPIO->DIRCLR[0] = (1UL<<BUTTON_USER1);   // input on PB8 (BUTTON_USER1)
    GPIO->CLR[0] = (1UL<<LED);    // LED is on PB9( turn off   )
    GPIO->DIRSET[0] = (1UL<<LED);    // output on PB9 (LED_USER2)
   // ----------------------- end of GPIO setup -----------------------------------

    // Set up GPIO IRQ: interrupt channel 0 (PINTSEL0) to GPIO 8
    SYSCON->PINTSEL[0] = BUTTON_USER1; // PINTSEL0 is P0_8

    // Configure the Pin interrupt mode register (a.k.a ISEL) for edge-sensitive
    // on PINTSEL0.  0 is edge sensitive. 1 is level sensitive.
    PINT->ISEL = 0x00; // channel 0 bit is 0: is edge sensitive (so are the other channels)
                                          // Use IENR or IENF (or S/CIENF or S/CIENR) to set edge type

    // Configure Chan 0 for only falling edge detection (no rising edge detection)
    PINT->CIENR = 0b00000001; // bit 0 is 1: disable channel 0 IRQ for rising edge
    PINT->SIENF = 0b00000001; // bit 0 is 1: enable channel 0 IRQ for falling edge


    // Remove any pending or left-over interrupt flags
    PINT->IST = 0xFF;  // each bit set to 1 removes any pending flag.

    // enable global interrupts & GPIO INT channel 0
    NVIC_EnableIRQ(PIN_INT0_IRQn); // GPIO interrupt

     __enable_irq();  // global

     /* Enter an infinite loop, check the pushbutton on GPIO8.*/
     while(1)
     {
    	 asm("NOP");
     }
     return 0 ;

} //end
// when user is pused blue-on.green=off       TOGGELe leds
