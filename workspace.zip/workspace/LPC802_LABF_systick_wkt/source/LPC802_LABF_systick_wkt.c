// EECS 3215 Lab F, Part 1 ... blocking
// User button is on PIO0_8 (GPIO 8)
// LED is PIO0_9 (GPIO 9)
//#include "LPC802.h"
//#include "clock_config.h"
//
//
//// #define LED (9)
//#define LED_USER2 (9) // LED (PIO0_9)
//
//// tell MC that we want the button to trigger a call to the ISR
//// therefore disable interrupt functionality while setting up for interrupts
//int main(void) {
//
//	SYSCON->SYSAHBCLKCTRL0 |= (SYSCON_SYSAHBCLKCTRL0_GPIO0_MASK); // GPIO is on
//
//	// PB (GPIO 8) for input and LED (GPIO 9) for output
//	GPIO->CLR[0] = (1UL<<LED_USER2); // LED is on PB9 (turn off)
//	GPIO->DIRSET[0] = (1UL<<LED_USER2); // output on PB9 (LED_USER2)
//
//	while (1) {
//		// asm("NOP");
//		for (int i = 0; i <= 3000000; i++) { // for loop that counts to a really big number (3,000,000)
//		}
//		GPIO->NOT[0] = (1UL<<LED_USER2); // inverts the value stored in LED
//
//	}
//	return 0;
//}
//
// EECS 3215 Lab F, Part 2 - Use SysTick-based heartbeat
// User button is on PIO0_8 (GPIO 8)
// LED is PIO0_9 (GPIO 9)
#include "LPC802.h"
#include "clock_config.h"
// #define LED (9)
#define LED_USER1 (8) // Blue LED (PIO0_8)
#define LED_USER2 (17) // red LED (PIO0_9)
// ISR for the SysTick... toggle an LED
void SysTick_Handler(void) {
	GPIO->NOT[0] = (1UL<<LED_USER2);
}
int main(void) {
	// disable interrupts (global (all) and SysTick (specific))
	__disable_irq(); // turn off globally
	NVIC_DisableIRQ(SysTick_IRQn); // turn off the SysTick interrupt
	// Set main clock to be the FRO (0X0)... 0x1 is the external clock
	SYSCON->MAINCLKSEL = (0X0<<SYSCON_MAINCLKSEL_SEL_SHIFT);
	// update the main clock
	// Step 1. Write - to bit - of this register
	// Step 2. write 1 to bit - this register
	SYSCON->MAINCLKUEN &= ~(0x1);
	SYSCON->MAINCLKUEN |= 0x1;
	// FRO frequency 9Mhz ... MSC
	BOARD_BootClockFRO18M();
	// Configure SysTick to fire once every 0.2 s
	SysTick_Config(9600000);
	SYSCON->SYSAHBCLKCTRL0 |= (SYSCON_SYSAHBCLKCTRL0_GPIO0_MASK); // GPIO is on
	// Put 0 in the GPIO reset bit to reset it
	// Then put a 1 in the GPIO reset bit to allow it to operate
	SYSCON->PRESETCTRL0 &= ~(SYSCON_PRESETCTRL0_GPIO0_RST_N_MASK); // Reset GPIO bit = 0
	SYSCON->PRESETCTRL0 |= (SYSCON_PRESETCTRL0_GPIO0_RST_N_MASK); // clear reset bit = 1
	GPIO->CLR[0] = (1UL<<LED_USER2); // LED is on PB9 (turn off)
	GPIO->DIRSET[0] = (1UL<<LED_USER2); // output on PB9 (LED_USER2)
	NVIC_EnableIRQ(SysTick_IRQn);
	__enable_irq(); // global
	while (1) {
		asm("NOP");
		// check pushbutton on GPIO8
	}
	return 0;
}
//
//
//// EECS 3215 Lab F, Part 3 - WKT
//// User button is on PIO0_8 (GPIO 8)
//// LED is PIO0_9 (GPIO 9)
//
//#include "LPC802.h"
//#include "clock_config.h"1
//
//// #define LED (9)
//#define LED_USER1 (8) // Blue LED (PIO0_8) WKT
//#define LED_USER2 (9) // Green LED (PIO0_9) SYSTICK
//
//#define WKT_FREQ 1000000 // Set to 3Hz
//#define WKT_RELOAD 166666 // reload value for the WKT down counter 3hz=1000000\relaod
//#define WKT_INT_FREQ (WKT_FREQ/WKT_RELOAD) // interrupt frequency of the WKT
//
//void WKT_Config() {
////	SYSCON->SYSAHBCLKCTRL0 |= (SYSCON_SYSAHBCLKCTRL0_GPIO0_MASK); // GPIO is on
//	GPIO->CLR[0] = (1UL<<LED_USER1); // LED is on PB9 (turn off)
//	GPIO->DIRSET[0] = (1UL<<LED_USER1); // output on PB9 (LED_USER2)
//	SYSCON->SYSAHBCLKCTRL0 |= (SYSCON_SYSAHBCLKCTRL0_WKT_MASK); // turn on wakeup timer enabling clock
//	NVIC_DisableIRQ(WKT_IRQn);
//	SYSCON->PDRUNCFG &= ~(SYSCON_PDRUNCFG_LPOSC_PD_MASK); // turn on the low power oscillator's power supply. bit 6 to 0 to turn ON (active low)
//	SYSCON->LPOSCCLKEN |= (SYSCON_LPOSCCLKEN_WKT_MASK);
//	SYSCON->PRESETCTRL0 &= ~(SYSCON_PRESETCTRL0_WKT_RST_N_MASK); // Reset WKT
//	SYSCON->PRESETCTRL0 |= (SYSCON_PRESETCTRL0_WKT_RST_N_MASK); // clear the reset
//	WKT->CTRL = WKT_CTRL_CLKSEL_MASK;
//	WKT->COUNT = WKT_RELOAD;
//	NVIC_EnableIRQ(WKT_IRQn);
//}
//
//// ISR for the SysTick... toggle an LED
//void SysTick_Handler(void) {
//	GPIO->NOT[0] = (1UL<<LED_USER2);
//}
//
//void WKT_IRQHandler(void) {
//	SYSCON->PRESETCTRL0 &= ~(SYSCON_PRESETCTRL0_WKT_RST_N_MASK); // Reset WKT
//	SYSCON->PRESETCTRL0 |= (SYSCON_PRESETCTRL0_WKT_RST_N_MASK); // clear the reset
//
//	WKT->COUNT = WKT_RELOAD;
//	//Toggle LED
//	GPIO->NOT[0] = (1UL<<LED_USER1);
//	return;
//}
//
//int main(void) {
//
////	WKT_Config();
//
//	// disable interrupts (global (all) and SysTick (specific))
//	__disable_irq(); // turn off globally
//	NVIC_DisableIRQ(SysTick_IRQn); // turn off the SysTick interrupt
//	// Set main clock to be the FRO (0X0)... 0x1 is the external clock
//	SYSCON->MAINCLKSEL = (0X0<<SYSCON_MAINCLKSEL_SEL_SHIFT);
//	// update the main clock
//	// Step 1. Write - to bit - of this register
//	// Step 2. write 1 to bit - this register
//	SYSCON->MAINCLKUEN &= ~(0x1);
//	SYSCON->MAINCLKUEN |= 0x1;
//
//	// FRO frequency 9Mhz ... MSC
//	BOARD_BootClockFRO18M();
//
//	// Configure SysTick to fire once every 0.2 s
//	SysTick_Config(4500000);
//	SYSCON->SYSAHBCLKCTRL0 |= (SYSCON_SYSAHBCLKCTRL0_GPIO0_MASK); // GPIO is on
//
//	// Put 0 in the GPIO reset bit to reset it
//	// Then put a 1 in the GPIO reset bit to allow it to operate
//	SYSCON->PRESETCTRL0 &= ~(SYSCON_PRESETCTRL0_GPIO0_RST_N_MASK); // Reset GPIO bit = 0
//	SYSCON->PRESETCTRL0 |= (SYSCON_PRESETCTRL0_GPIO0_RST_N_MASK); // clear reset bit = 1
//
//	WKT_Config();
//
//	GPIO->CLR[0] = (1UL<<LED_USER2); // LED is on PB9 (turn off)
//	GPIO->DIRSET[0] = (1UL<<LED_USER2); // output on PB9 (LED_USER2)
//
//	NVIC_EnableIRQ(SysTick_IRQn);
//	__enable_irq(); // global
//
//	while (1) {
//		asm("NOP");
//		// check pushbutton on GPIO8
//	}
//	return 0;
//}
